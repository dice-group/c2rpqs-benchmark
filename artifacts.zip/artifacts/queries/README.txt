The file c2rpqs.txt contains the queries that we used in our evaluation. Each query is assigned an ID.

